package UF4.HerenciaMultinivellAct;

/**
 * Seat
 *
 * @author Daniel Saavedra Escuder
 * @version 18/04/2023
 */

public class Seat extends Car{
    private String model;

    public Seat() {

    }

    public void brand() {

    }

    public void speed() {

    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}
