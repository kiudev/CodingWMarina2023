package UF4.HerenciaMultinivellAct;

/**
 * Arona
 *
 * @author Daniel Saavedra Escuder
 * @version 18/04/2023
 */

public class Arona extends Seat{
    private String color;
    private double km;

    public Arona() {

    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getKm() {
        return km;
    }

    public void setKm(double km) {
        this.km = km;
    }
}
