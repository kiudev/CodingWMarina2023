package UF4.HerenciaMultinivellAct;

/**
 * Car
 *
 * @author Daniel Saavedra Escuder
 * @version 18/04/2023
 */

public class Car {
    private int id;

    public Car() {

    }

    public void vehicleType() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
