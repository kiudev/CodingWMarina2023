package UF5.Dropdown;

public class Main {
    public static void main(String[] args) {
        Window window = new Window();
        window.setVisible(true);
        window.setLocationRelativeTo(null);
        window.setResizable(false);
    }
}
